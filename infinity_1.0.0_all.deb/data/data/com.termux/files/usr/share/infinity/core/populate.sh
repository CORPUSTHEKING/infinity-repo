#!/bin/bash
# Infinity Directory Population Script

TOOLS=(
    "Login/Sign up" "Resume" "Infinity Ai" "File Opps" 
    "Command Constructor" "Search" "Screenshot" "Tools Setup" 
    "Suggest" "Favourites" "Help & Q/A" "Settings" 
    "Donate" "About Infinity" "Abstract"
)

BASE_PATH="/data/data/com.termux/files/home/.infinity/tools"

echo "--- 🛠️  Populating Infinity Structure ---"
for tool in "${TOOLS[@]}"; do
    mkdir -vp "$BASE_PATH/$tool"
    touch "$BASE_PATH/$tool/${tool// /_}.md"
    echo "# $tool" > "$BASE_PATH/$tool/README.md"
    echo "---" >> "$BASE_PATH/$tool/Settings.md"
done
